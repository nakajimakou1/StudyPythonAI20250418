# pytorch_mnist
PytorchでMNIST分類のモデルを 全結合層・CNN・RNN・LSTMの4パターン実装したリポジトリです。
